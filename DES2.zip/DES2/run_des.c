#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/*
 * des.h provides the following functions and constants:
 *
 * generate_key, generate_sub_keys, process_message, ENCRYPTION_MODE, DECRYPTION_MODE
 *
 */
#include "des.h"

// Declare file handlers
static FILE *key_file, *input_file, *output_file;

// Declare action parameters
#define ACTION_GENERATE_KEY "-g"
#define ACTION_ENCRYPT "-e"
#define ACTION_DECRYPT "-d"

// DES key is 8 bytes long
#define DES_KEY_SIZE 8

int main(int argc, char* argv[])
{
    clock_t start, finish;
    double time_taken;
    unsigned long file_size;
    unsigned short int padding;
    int choose;
    char keyfile[15],inputfile[15],outputfile[15];
    while(1)
    {
        printf("1.������Կ�ļ�\n");
        printf("2.�����ļ�\n");
        printf("3.�����ļ�\n");
        printf("4.�˳�\n");
        printf("��ѡ��:");
        scanf("%d",&choose);
        if(choose == 4)
            break;
        if (choose == 1)   // Generate key file
        {
            printf("��������Կ�ļ�������:");
            fgetc(stdin);
            scanf("%s",keyfile);
            key_file = fopen(keyfile, "wb");
            if (!key_file)
            {
                printf("Could not open file to write key.");
                return 1;
            }

            unsigned int iseed = (unsigned int)time(NULL);
            srand (iseed);

            short int bytes_written;
            //��Կ����
            unsigned char* des_key = (unsigned char*) malloc(8*sizeof(char));
            generate_key(des_key);
            bytes_written = fwrite(des_key, 1, DES_KEY_SIZE, key_file);
            if (bytes_written != DES_KEY_SIZE)
            {
                printf("Error writing key to output file.");
                fclose(key_file);
                free(des_key);
                return 1;
            }

            free(des_key);
            fclose(key_file);
        }
        else if (choose == 2 || choose == 3)     // Encrypt or decrypt
        {
            // Read key file
            printf("��������Կ�ļ�������:");
            fgetc(stdin);
            scanf("%s",keyfile);
            key_file = fopen(keyfile, "rb");
            if (!key_file)
            {
                printf("Could not open key file to read key.");
                return 1;
            }

            short int bytes_read;
            unsigned char* des_key = (unsigned char*) malloc(8*sizeof(char));
            bytes_read = fread(des_key, sizeof(unsigned char), DES_KEY_SIZE, key_file);
            if (bytes_read != DES_KEY_SIZE)
            {
                printf("Key read from key file does nto have valid key size.");
                fclose(key_file);
                return 1;
            }
            fclose(key_file);

            // Open input file
            printf("�����ļ�������:");
            fgetc(stdin);
            scanf("%s",inputfile);
            input_file = fopen(inputfile, "rb");
            if (!input_file)
            {
                printf("Could not open input file to read data.");
                return 1;
            }

            // Open output file
            printf("����ļ�������:");
            fgetc(stdin);
            scanf("%s",outputfile);
            output_file = fopen(outputfile, "wb");
            if (!output_file)
            {
                printf("Could not open output file to write data.");
                return 1;
            }

            // Generate DES key set
            short int bytes_written, process_mode;
            unsigned long block_count = 0, number_of_blocks;
            unsigned char* data_block = (unsigned char*) malloc(8*sizeof(char));
            unsigned char* processed_block = (unsigned char*) malloc(8*sizeof(char));
            key_set* key_sets = (key_set*)malloc(17*sizeof(key_set));

            start = clock();
            generate_sub_keys(des_key, key_sets);
            finish = clock();
            time_taken = (double)(finish - start)/(double)CLOCKS_PER_SEC;

            // Determine process mode
            if (choose == 2)
            {
                process_mode = ENCRYPTION_MODE;
                printf("Encrypting..\n");
            }
            else
            {
                process_mode = DECRYPTION_MODE;
                printf("Decrypting..\n");
            }

            // Get number of blocks in the file
            fseek(input_file, 0L, SEEK_END);
            file_size = ftell(input_file);

            fseek(input_file, 0L, SEEK_SET);
            number_of_blocks = file_size/8 + ((file_size%8)?1:0);

            start = clock();

            // Start reading input file, process and write to output file
            while(fread(data_block, 1, 8, input_file))
            {
                block_count++;
                if (block_count == number_of_blocks)
                {
                    if (process_mode == ENCRYPTION_MODE)
                    {
                        padding = 8 - file_size%8;
                        if (padding < 8)   // Fill empty data block bytes with padding
                        {
                            memset((data_block + 8 - padding), (unsigned char)padding, padding);
                        }

                        process_message(data_block, processed_block, key_sets, process_mode);
                        bytes_written = fwrite(processed_block, 1, 8, output_file);

                        if (padding == 8)   // Write an extra block for padding
                        {
                            memset(data_block, (unsigned char)padding, 8);
                            process_message(data_block, processed_block, key_sets, process_mode);
                            bytes_written = fwrite(processed_block, 1, 8, output_file);
                        }
                    }
                    else
                    {
                        process_message(data_block, processed_block, key_sets, process_mode);
                        padding = processed_block[7];

                        if (padding < 8)
                        {
                            bytes_written = fwrite(processed_block, 1, 8 - padding, output_file);
                        }
                    }
                }
                else
                {
                    process_message(data_block, processed_block, key_sets, process_mode);
                    bytes_written = fwrite(processed_block, 1, 8, output_file);
                }
                memset(data_block, 0, 8);
            }

            finish = clock();

            // Free up memory
            free(des_key);
            free(data_block);
            free(processed_block);
            fclose(input_file);
            fclose(output_file);

            // Provide feedback
            time_taken = (double)(finish - start)/(double)CLOCKS_PER_SEC;
        }
    }
    return 0;
}
